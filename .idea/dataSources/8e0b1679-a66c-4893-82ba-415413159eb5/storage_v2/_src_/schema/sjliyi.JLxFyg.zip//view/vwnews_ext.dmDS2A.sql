create view vwnews_ext as
  select
    `a`.`id`           AS `id`,
    `a`.`name`         AS `name`,
    `a`.`createDate`   AS `createDate`,
    `a`.`sendDate`     AS `sendDate`,
    `a`.`web`          AS `web`,
    `a`.`newsBlock`    AS `newsBlock`,
    `a`.`type`         AS `type`,
    `a`.`videoAddress` AS `videoAddress`,
    `a`.`isShare`      AS `isShare`,
    `a`.`status`       AS `status`,
    `a`.`userID`       AS `userID`,
    `a`.`actorID`      AS `actorID`,
    `a`.`orgID`        AS `orgID`,
    `b`.`name`         AS `webName`,
    `c`.`name`         AS `cateName`,
    `a`.`content`      AS `content`
  from ((`sjliyi`.`news` `a`
    join `sjliyi`.`website` `b`) join `sjliyi`.`newscategory` `c` on (('' = '')))
  where ((`a`.`web` = `b`.`id`) and (`a`.`newsBlock` = `c`.`id`));

