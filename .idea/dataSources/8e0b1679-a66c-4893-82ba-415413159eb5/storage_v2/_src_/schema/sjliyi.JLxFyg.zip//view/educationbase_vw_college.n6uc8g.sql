create view educationbase_vw_college as
  select
    `a`.`id`         AS `id`,
    `a`.`id`         AS `oldId`,
    `a`.`name`       AS `name`,
    `a`.`createDate` AS `createDate`,
    `a`.`address`    AS `address`,
    `a`.`logo`       AS `logo`,
    `a`.`postcode`   AS `postcode`,
    `a`.`url`        AS `url`,
    `a`.`introduce`  AS `introduce`,
    `a`.`charger`    AS `charger`,
    `a`.`status`     AS `status`,
    `a`.`user`       AS `user`,
    `a`.`actor`      AS `actor`,
    `a`.`org`        AS `org`,
    `b`.`name`       AS `userName`,
    `c`.`name`       AS `actorName`
  from ((`sjliyi`.`educationbase_college` `a`
    join `sjliyi`.`users` `b`) join `sjliyi`.`actor` `c`)
  where ((`a`.`user` = `b`.`id`) and (`a`.`actor` = `c`.`id`));

