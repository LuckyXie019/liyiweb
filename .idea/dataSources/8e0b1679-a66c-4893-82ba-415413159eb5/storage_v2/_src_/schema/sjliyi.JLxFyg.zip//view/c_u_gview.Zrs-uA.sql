create view c_u_gview as
  select
    `c`.`id`             AS `id`,
    `u`.`name`           AS `name`,
    `c`.`content`        AS `content`,
    `c`.`complaintstime` AS `complaintstime`,
    `c`.`processed`      AS `processed`,
    `c`.`status`         AS `status`,
    `u`.`phone`          AS `phone`,
    `c`.`u_id`           AS `u_id`,
    `c`.`c_id`           AS `c_id`,
    `s`.`storename`      AS `storename`
  from ((`sjliyi`.`i_complaints` `c`
    join `sjliyi`.`i_user` `u`) join `sjliyi`.`i_store` `s`)
  where ((`c`.`u_id` = `u`.`id`) and (`u`.`s_id` = `s`.`id`));

