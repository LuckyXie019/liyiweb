create view shoppingcartview as
  select
    `sjliyi`.`i_shoppingcart`.`acount` AS `acount`,
    `sjliyi`.`i_shoppingcart`.`c_id`   AS `c_id`,
    `sjliyi`.`i_shoppingcart`.`st_id`  AS `st_id`,
    `sjliyi`.`i_shoppingcart`.`u_id`   AS `u_id`,
    `sjliyi`.`i_shoppingcart`.`id`     AS `id`,
    `sjliyi`.`i_commodity`.`commname`  AS `commname`,
    `sjliyi`.`i_commodity`.`price`     AS `price`,
    `sjliyi`.`i_style`.`styleImage`    AS `styleImage`,
    `sjliyi`.`i_style`.`stylename`     AS `stylename`,
    `sjliyi`.`i_commodity`.`status`    AS `status`,
    `sjliyi`.`i_commodity`.`s_id`      AS `s_id`,
    `sjliyi`.`i_store`.`storename`     AS `storename`
  from (((`sjliyi`.`i_shoppingcart`
    join `sjliyi`.`i_commodity` on ((`sjliyi`.`i_shoppingcart`.`c_id` = `sjliyi`.`i_commodity`.`id`))) join
    `sjliyi`.`i_style` on ((`sjliyi`.`i_shoppingcart`.`st_id` = `sjliyi`.`i_style`.`id`))) join `sjliyi`.`i_store`
      on ((`sjliyi`.`i_commodity`.`s_id` = `sjliyi`.`i_store`.`id`)));

