create view vwusermapactor as
  select
    `a`.`id`          AS `id`,
    `a`.`name`        AS `name`,
    `a`.`createDate`  AS `createDate`,
    `a`.`description` AS `description`,
    `a`.`type`        AS `type`,
    `a`.`status`      AS `status`,
    `a`.`parent`      AS `parent`,
    `a`.`typeName`    AS `typeName`,
    `b`.`userID`      AS `userID`
  from (`sjliyi`.`vwactor` `a`
    join `sjliyi`.`usermapactor` `b`)
  where (`a`.`id` = `b`.`actorID`);

