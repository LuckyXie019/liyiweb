create view vwadvertisement as
  select
    `a`.`id`           AS `id`,
    `a`.`name`         AS `name`,
    `a`.`createDate`   AS `createDate`,
    `a`.`imgAddress`   AS `imgAddress`,
    `a`.`videoAddress` AS `videoAddress`,
    `a`.`linkUrl`      AS `linkUrl`,
    `a`.`homeUrl`      AS `homeUrl`,
    `a`.`content`      AS `content`,
    `a`.`type`         AS `type`,
    `a`.`posX`         AS `posX`,
    `a`.`posY`         AS `posY`,
    `a`.`width`        AS `width`,
    `a`.`height`       AS `height`,
    `a`.`duration`     AS `duration`,
    `a`.`web`          AS `web`,
    `a`.`userID`       AS `userID`,
    `a`.`actorID`      AS `actorID`,
    `a`.`orgID`        AS `orgID`,
    `a`.`status`       AS `status`,
    `b`.`name`         AS `webSiteName`,
    `c`.`name`         AS `userName`
  from ((`sjliyi`.`advertisement` `a`
    join `sjliyi`.`website` `b`) join `sjliyi`.`users` `c`)
  where ((`a`.`web` = `b`.`id`) and (`a`.`userID` = `c`.`id`));

