create view st_lp as
  select
    `sjliyi`.`i_strategy`.`id`          AS `id`,
    `sjliyi`.`i_strategy`.`commname`    AS `commname`,
    `sjliyi`.`i_strategy`.`sub_id`      AS `sub_id`,
    `sjliyi`.`i_strategy`.`title`       AS `title`,
    `sjliyi`.`i_strategy`.`image1`      AS `image1`,
    `sjliyi`.`i_strategy`.`image2`      AS `image2`,
    `sjliyi`.`i_strategy`.`image3`      AS `image3`,
    `sjliyi`.`i_strategy`.`image4`      AS `image4`,
    `sjliyi`.`i_strategy`.`description` AS `description`,
    `sjliyi`.`i_strategy`.`price`       AS `price`,
    `sjliyi`.`i_strategy`.`stock`       AS `stock`,
    `sjliyi`.`i_strategy`.`time`        AS `time`,
    `sjliyi`.`i_strategy`.`s_id`        AS `s_id`,
    `sjliyi`.`i_strategy`.`integral`    AS `integral`,
    `sjliyi`.`i_strategy`.`status`      AS `status`,
    `sjliyi`.`i_strategy`.`sales`       AS `sales`,
    `sjliyi`.`i_strategy`.`sstatus`     AS `sstatus`,
    `sjliyi`.`i_strategy`.`reason`      AS `reason`,
    `sjliyi`.`i_strategy`.`grade`       AS `grade`,
    `sjliyi`.`i_style`.`styleImage`     AS `styleImage`,
    `sjliyi`.`i_style`.`stylename`      AS `stylename`,
    `sjliyi`.`i_store`.`storename`      AS `storename`
  from ((`sjliyi`.`i_strategy`
    join `sjliyi`.`i_style`) join `sjliyi`.`i_store`)
  where ((`sjliyi`.`i_strategy`.`s_id` = `sjliyi`.`i_store`.`id`) and
         (`sjliyi`.`i_strategy`.`id` = `sjliyi`.`i_style`.`com_id`));

