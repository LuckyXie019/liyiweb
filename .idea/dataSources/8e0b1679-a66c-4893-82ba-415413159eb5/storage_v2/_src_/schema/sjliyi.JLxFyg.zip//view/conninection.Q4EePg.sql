create view conninection as
  select
    `o`.`id`                          AS `id`,
    `o`.`orders_id`                   AS `orders_id`,
    `o`.`ordertime`                   AS `ordertime`,
    `c`.`commname`                    AS `commname`,
    `o`.`goodsnumber`                 AS `goodsnumber`,
    `c`.`price`                       AS `price`,
    (`o`.`goodsnumber` * `c`.`price`) AS `reality`,
    `s`.`storename`                   AS `storename`,
    `o`.`status`                      AS `status`,
    `st`.`stylename`                  AS `stylename`,
    `l`.`logisticsname`               AS `logisticsname`,
    `o`.`c_id`                        AS `c_id`,
    `o`.`st_id`                       AS `st_id`,
    `o`.`logisticsnumber`             AS `logisticsnumber`,
    `c`.`s_id`                        AS `s_id`,
    `s`.`storeimage`                  AS `storeimage`
  from ((((`sjliyi`.`i_orders` `o`
    join `sjliyi`.`i_store` `s`) join `sjliyi`.`i_commodity` `c`) join `sjliyi`.`i_style` `st`) join
    `sjliyi`.`i_logistics` `l`)
  where ((`o`.`c_id` = `c`.`id`) and (`o`.`st_id` = `st`.`id`) and (`s`.`id` = `c`.`s_id`));

