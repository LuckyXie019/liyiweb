create view storevxiaoliangiew as
  select
    `sjliyi`.`i_store`.`id`           AS `id`,
    `sjliyi`.`i_store`.`storename`    AS `storename`,
    `sjliyi`.`i_store`.`description`  AS `description`,
    `sjliyi`.`i_store`.`province`     AS `province`,
    `sjliyi`.`i_store`.`city`         AS `city`,
    `sjliyi`.`i_store`.`area`         AS `area`,
    `sjliyi`.`i_store`.`address`      AS `address`,
    `sjliyi`.`i_store`.`storeimage`   AS `storeimage`,
    `sjliyi`.`i_store`.`status`       AS `status`,
    `sjliyi`.`i_store`.`number`       AS `number`,
    `sjliyi`.`i_store`.`idcard`       AS `idcard`,
    `sjliyi`.`i_store`.`idimage`      AS `idimage`,
    `sjliyi`.`i_store`.`bcnumber`     AS `bcnumber`,
    `sjliyi`.`i_store`.`time`         AS `time`,
    `sjliyi`.`i_store`.`d_id`         AS `d_id`,
    `sjliyi`.`i_store`.`credit`       AS `credit`,
    `sjliyi`.`i_store`.`approval`     AS `approval`,
    `sjliyi`.`i_commodity`.`commname` AS `commname`,
    `sjliyi`.`i_commodity`.`image1`   AS `image1`,
    `sjliyi`.`i_orders`.`c_id`        AS `c_id`
  from ((`sjliyi`.`i_orders`
    join `sjliyi`.`i_commodity` on ((`sjliyi`.`i_orders`.`c_id` = `sjliyi`.`i_commodity`.`id`))) join `sjliyi`.`i_store`
      on ((`sjliyi`.`i_commodity`.`s_id` = `sjliyi`.`i_store`.`id`)));

