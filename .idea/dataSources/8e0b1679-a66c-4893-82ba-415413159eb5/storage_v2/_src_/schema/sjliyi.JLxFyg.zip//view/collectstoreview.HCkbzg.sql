create view collectstoreview as
  select
    `sjliyi`.`i_collect`.`id`         AS `id`,
    `sjliyi`.`i_collect`.`u_id`       AS `u_id`,
    `sjliyi`.`i_collect`.`s_id`       AS `s_id`,
    `sjliyi`.`i_store`.`storename`    AS `storename`,
    `sjliyi`.`i_commodity`.`commname` AS `commname`,
    `sjliyi`.`i_commodity`.`id`       AS `comid`,
    `sjliyi`.`i_commodity`.`image1`   AS `image1`,
    `sjliyi`.`i_commodity`.`image2`   AS `image2`,
    `sjliyi`.`i_commodity`.`image3`   AS `image3`,
    `sjliyi`.`i_commodity`.`image4`   AS `image4`,
    `sjliyi`.`i_commodity`.`price`    AS `price`,
    `sjliyi`.`i_commodity`.`status`   AS `status`,
    `sjliyi`.`i_commodity`.`sstatus`  AS `sstatus`,
    `sjliyi`.`i_commodity`.`time`     AS `time`,
    `sjliyi`.`i_store`.`storeimage`   AS `storeimage`
  from ((`sjliyi`.`i_collect`
    join `sjliyi`.`i_store` on ((`sjliyi`.`i_collect`.`s_id` = `sjliyi`.`i_store`.`id`))) join `sjliyi`.`i_commodity`
      on ((`sjliyi`.`i_commodity`.`s_id` = `sjliyi`.`i_store`.`id`)));

