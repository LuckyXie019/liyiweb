create view sy_yj as
  select
    `sjliyi`.`i_deposit`.`id`      AS `id`,
    `sjliyi`.`i_user`.`name`       AS `name`,
    `sjliyi`.`i_deposit`.`deposit` AS `deposit`,
    `sjliyi`.`i_deposit`.`status`  AS `status`
  from (`sjliyi`.`i_deposit`
    join `sjliyi`.`i_user`)
  where (`sjliyi`.`i_deposit`.`u_id` = `sjliyi`.`i_user`.`id`);

