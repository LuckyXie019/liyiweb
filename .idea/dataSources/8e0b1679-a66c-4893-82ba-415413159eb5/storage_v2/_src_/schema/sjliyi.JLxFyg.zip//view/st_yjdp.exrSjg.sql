create view st_yjdp as
  select
    `d`.`id`        AS `id`,
    `u`.`name`      AS `name`,
    `s`.`storename` AS `storename`,
    `d`.`deposit`   AS `deposit`,
    `d`.`status`    AS `status`
  from ((`sjliyi`.`i_deposit` `d`
    join `sjliyi`.`i_user` `u`) join `sjliyi`.`i_store` `s`)
  where ((`d`.`u_id` = `u`.`id`) and (`u`.`s_id` = `s`.`id`));

