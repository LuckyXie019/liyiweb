create view vwclerk as
  select
    `a`.`id`         AS `id`,
    `a`.`gh`         AS `gh`,
    `a`.`xm`         AS `xm`,
    `a`.`ywxm`       AS `ywxm`,
    `a`.`xmpy`       AS `xmpy`,
    `a`.`cym`        AS `cym`,
    `a`.`xbm`        AS `xbm`,
    `a`.`csrq`       AS `csrq`,
    `a`.`csdm`       AS `csdm`,
    `a`.`jg`         AS `jg`,
    `a`.`mzm`        AS `mzm`,
    `a`.`gjdqm`      AS `gjdqm`,
    `a`.`sfzjlxm`    AS `sfzjlxm`,
    `a`.`sfzjh`      AS `sfzjh`,
    `a`.`hyzkm`      AS `hyzkm`,
    `a`.`zzmmm`      AS `zzmmm`,
    `a`.`jkzkm`      AS `jkzkm`,
    `a`.`xyzjm`      AS `xyzjm`,
    `a`.`xxm`        AS `xxm`,
    `a`.`zp`         AS `zp`,
    `a`.`sfzjyxq`    AS `sfzjyxq`,
    `a`.`status`     AS `status`,
    `a`.`userID`     AS `userID`,
    `a`.`actorID`    AS `actorID`,
    `a`.`orgID`      AS `orgID`,
    `b`.`name`       AS `orgName`,
    `a`.`createDate` AS `createDate`
  from (`sjliyi`.`clerk` `a`
    join `sjliyi`.`organization` `b`)
  where (`a`.`orgID` = `b`.`id`);

