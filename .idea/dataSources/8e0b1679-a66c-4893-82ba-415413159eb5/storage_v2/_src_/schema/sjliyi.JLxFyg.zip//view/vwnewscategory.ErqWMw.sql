create view vwnewscategory as
  select
    `a`.`id`          AS `id`,
    `a`.`name`        AS `name`,
    `a`.`createDate`  AS `createDate`,
    `a`.`web`         AS `web`,
    `a`.`description` AS `description`,
    `a`.`status`      AS `status`,
    `a`.`userID`      AS `userID`,
    `a`.`actorID`     AS `actorID`,
    `a`.`orgID`       AS `orgID`,
    `b`.`name`        AS `webName`,
    `a`.`parent`      AS `parent`
  from (`sjliyi`.`newscategory` `a`
    join `sjliyi`.`website` `b`)
  where (`a`.`web` = `b`.`id`);

