create view st_dpjf as
  select
    `c`.`id`          AS `id`,
    `c`.`commname`    AS `commname`,
    `c`.`sub_id`      AS `sub_id`,
    `c`.`title`       AS `title`,
    `c`.`image1`      AS `image1`,
    `c`.`image2`      AS `image2`,
    `c`.`image3`      AS `image3`,
    `c`.`image4`      AS `image4`,
    `c`.`description` AS `description`,
    `c`.`price`       AS `price`,
    `c`.`stock`       AS `stock`,
    `c`.`time`        AS `time`,
    `c`.`s_id`        AS `s_id`,
    `c`.`integral`    AS `integral`,
    `c`.`status`      AS `status`,
    `c`.`sales`       AS `sales`,
    `c`.`sstatus`     AS `sstatus`,
    `s`.`storename`   AS `storename`
  from (`sjliyi`.`i_commodity` `c`
    join `sjliyi`.`i_store` `s`)
  where ((`c`.`s_id` = `s`.`id`) and (not (`c`.`id` in (select `sjliyi`.`i_strategy`.`id`
                                                        from `sjliyi`.`i_strategy`))));

