create view evaluationview as
  select
    `sjliyi`.`i_evaluation`.`id`         AS `id`,
    `sjliyi`.`i_evaluation`.`o_id`       AS `o_id`,
    `sjliyi`.`i_evaluation`.`assess`     AS `assess`,
    `sjliyi`.`i_evaluation`.`assesstime` AS `assesstime`,
    `sjliyi`.`i_evaluation`.`reply`      AS `reply`,
    `sjliyi`.`i_evaluation`.`type`       AS `type`,
    `sjliyi`.`i_evaluation`.`replytime`  AS `replytime`,
    `sjliyi`.`i_user`.`nickname`         AS `nickname`,
    `sjliyi`.`i_store`.`storename`       AS `storename`,
    `sjliyi`.`i_store`.`id`              AS `storeid`,
    `sjliyi`.`i_orders`.`reality`        AS `reality`,
    `sjliyi`.`i_style`.`stylename`       AS `stylename`,
    `sjliyi`.`i_commodity`.`commname`    AS `commname`,
    `sjliyi`.`i_orders`.`status`         AS `status`,
    `sjliyi`.`i_commodity`.`id`          AS `comid`,
    `sjliyi`.`i_orders`.`evalustatus`    AS `evalustatus`,
    `sjliyi`.`i_evaluation`.`status`     AS `evstatus`,
    `sjliyi`.`i_user`.`id`               AS `uid`,
    `sjliyi`.`i_style`.`styleImage`      AS `styleImage`
  from (((((`sjliyi`.`i_evaluation`
    join `sjliyi`.`i_orders` on ((`sjliyi`.`i_evaluation`.`o_id` = `sjliyi`.`i_orders`.`id`))) join `sjliyi`.`i_user`
      on ((`sjliyi`.`i_orders`.`u_id` = `sjliyi`.`i_user`.`id`))) join `sjliyi`.`i_style`
      on ((`sjliyi`.`i_orders`.`st_id` = `sjliyi`.`i_style`.`id`))) join `sjliyi`.`i_commodity`
      on ((`sjliyi`.`i_orders`.`c_id` = `sjliyi`.`i_commodity`.`id`))) join `sjliyi`.`i_store`
      on ((`sjliyi`.`i_commodity`.`s_id` = `sjliyi`.`i_store`.`id`)));

