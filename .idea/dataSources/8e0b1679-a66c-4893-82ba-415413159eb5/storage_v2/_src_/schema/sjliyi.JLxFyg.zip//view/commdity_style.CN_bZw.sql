create view commdity_style as
  select
    `c`.`id`                       AS `id`,
    `c`.`commname`                 AS `commname`,
    `c`.`price`                    AS `price`,
    `c`.`stock`                    AS `stock`,
    `s`.`stylename`                AS `stylename`,
    `sjliyi`.`i_user`.`id`         AS `userid`,
    `sjliyi`.`i_store`.`storename` AS `storename`,
    `sjliyi`.`i_user`.`s_id`       AS `s_id`
  from (((`sjliyi`.`i_commodity` `c`
    join `sjliyi`.`i_style` `s` on ((`c`.`id` = `s`.`com_id`))) join `sjliyi`.`i_store`
      on ((`c`.`s_id` = `sjliyi`.`i_store`.`id`))) join `sjliyi`.`i_user`
      on ((`sjliyi`.`i_user`.`s_id` = `sjliyi`.`i_store`.`id`)));

