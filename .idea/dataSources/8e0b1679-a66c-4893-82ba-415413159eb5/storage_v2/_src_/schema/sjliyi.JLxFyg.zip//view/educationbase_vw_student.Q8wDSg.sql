create view educationbase_vw_student as
  select
    `a`.`id`         AS `id`,
    `a`.`name`       AS `name`,
    `a`.`createDate` AS `createDate`,
    `a`.`sex`        AS `sex`,
    `a`.`status`     AS `status`,
    `a`.`user`       AS `user`,
    `a`.`actor`      AS `actor`,
    `a`.`org`        AS `org`,
    `b`.`name`       AS `userName`,
    `c`.`name`       AS `actorName`
  from ((`sjliyi`.`educationbase_student` `a`
    join `sjliyi`.`users` `b`) join `sjliyi`.`actor` `c`)
  where ((`a`.`user` = `b`.`id`) and (`a`.`actor` = `c`.`id`));

