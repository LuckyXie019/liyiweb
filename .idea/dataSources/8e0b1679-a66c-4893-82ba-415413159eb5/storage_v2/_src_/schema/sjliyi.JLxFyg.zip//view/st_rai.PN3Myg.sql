create view st_rai as
  select
    `sjliyi`.`i_raiders`.`id`          AS `id`,
    `sjliyi`.`i_raiders`.`u_id`        AS `u_id`,
    `sjliyi`.`i_raiders`.`time`        AS `time`,
    `sjliyi`.`i_raiders`.`content`     AS `content`,
    `sjliyi`.`i_raiders`.`status`      AS `status`,
    `sjliyi`.`i_raiders`.`reason`      AS `reason`,
    `sjliyi`.`i_raiders`.`sub_id`      AS `sub_id`,
    `sjliyi`.`i_raiders`.`likenum`     AS `likenum`,
    `sjliyi`.`i_raiders`.`title`       AS `title`,
    `sjliyi`.`i_raiders`.`image`       AS `image`,
    `sjliyi`.`i_raiders`.`description` AS `description`,
    `sjliyi`.`i_user`.`name`           AS `name`
  from ((`sjliyi`.`i_raiders`
    join `sjliyi`.`i_user`) join `sjliyi`.`i_category`)
  where ((`sjliyi`.`i_raiders`.`u_id` = `sjliyi`.`i_user`.`id`) and
         (`sjliyi`.`i_raiders`.`sub_id` = `sjliyi`.`i_category`.`subid`));

