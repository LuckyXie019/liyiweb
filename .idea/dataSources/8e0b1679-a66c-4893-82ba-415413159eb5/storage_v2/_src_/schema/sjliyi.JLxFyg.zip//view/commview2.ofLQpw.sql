create view commview2 as
  select
    `sjliyi`.`i_category`.`id`           AS `id`,
    `sjliyi`.`i_category`.`category`     AS `category`,
    `sjliyi`.`i_category`.`subid`        AS `subid`,
    `sjliyi`.`i_category`.`subcategory`  AS `subcategory`,
    `sjliyi`.`i_commodity`.`commname`    AS `commname`,
    `sjliyi`.`i_commodity`.`id`          AS `comid`,
    `sjliyi`.`i_commodity`.`sub_id`      AS `sub_id`,
    `sjliyi`.`i_commodity`.`image2`      AS `image2`,
    `sjliyi`.`i_commodity`.`image1`      AS `image1`,
    `sjliyi`.`i_commodity`.`image3`      AS `image3`,
    `sjliyi`.`i_commodity`.`image4`      AS `image4`,
    `sjliyi`.`i_commodity`.`description` AS `comdescription`,
    `sjliyi`.`i_commodity`.`stock`       AS `stock`,
    `sjliyi`.`i_commodity`.`price`       AS `price`,
    `sjliyi`.`i_commodity`.`status`      AS `status`,
    `sjliyi`.`i_commodity`.`sstatus`     AS `sstatus`,
    `sjliyi`.`i_commodity`.`s_id`        AS `s_id`,
    `sjliyi`.`i_store`.`storename`       AS `storename`,
    `sjliyi`.`i_store`.`rank`            AS `rank`,
    `sjliyi`.`i_store`.`credit`          AS `credit`,
    `sjliyi`.`i_store`.`storeimage`      AS `storeimage`,
    `sjliyi`.`i_commodity`.`time`        AS `time`
  from ((`sjliyi`.`i_commodity`
    join `sjliyi`.`i_category` on ((`sjliyi`.`i_commodity`.`sub_id` = `sjliyi`.`i_category`.`subid`))) join
    `sjliyi`.`i_store` on ((`sjliyi`.`i_commodity`.`s_id` = `sjliyi`.`i_store`.`id`)));

