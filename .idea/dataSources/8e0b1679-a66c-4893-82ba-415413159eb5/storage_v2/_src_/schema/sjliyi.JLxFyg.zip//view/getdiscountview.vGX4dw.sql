create view getdiscountview as
  select
    `sjliyi`.`i_store`.`storename`   AS `storename`,
    `sjliyi`.`i_discount`.`id`       AS `id`,
    `sjliyi`.`i_discount`.`amount`   AS `amount`,
    `sjliyi`.`i_discount`.`s_id`     AS `s_id`,
    `sjliyi`.`i_get`.`id`            AS `get_id`,
    `sjliyi`.`i_get`.`u_id`          AS `u_id`,
    `sjliyi`.`i_get`.`status`        AS `status`,
    `sjliyi`.`i_discount`.`require1` AS `require1`
  from ((`sjliyi`.`i_get`
    join `sjliyi`.`i_discount` on ((`sjliyi`.`i_get`.`dis_id` = `sjliyi`.`i_discount`.`id`))) join `sjliyi`.`i_store`
      on ((`sjliyi`.`i_discount`.`s_id` = `sjliyi`.`i_store`.`id`)));

