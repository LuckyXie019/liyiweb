create view vwnotice as
  select
    `a`.`id`         AS `id`,
    `a`.`name`       AS `name`,
    `a`.`createDate` AS `createDate`,
    `a`.`content`    AS `content`,
    `a`.`sendDate`   AS `sendDate`,
    `a`.`web`        AS `web`,
    `a`.`status`     AS `status`,
    `a`.`userID`     AS `userID`,
    `a`.`actorID`    AS `actorID`,
    `a`.`orgID`      AS `orgID`,
    `b`.`name`       AS `webName`
  from (`sjliyi`.`notice` `a`
    join `sjliyi`.`website` `b`)
  where (`a`.`web` = `b`.`id`);

