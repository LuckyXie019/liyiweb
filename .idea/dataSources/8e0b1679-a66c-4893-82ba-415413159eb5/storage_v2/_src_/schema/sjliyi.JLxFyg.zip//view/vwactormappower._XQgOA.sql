create view vwactormappower as
  select
    `b`.`name`    AS `actorName`,
    `c`.`name`    AS `name`,
    `c`.`address` AS `address`,
    `c`.`status`  AS `status`,
    `a`.`actorID` AS `actorID`,
    `c`.`id`      AS `id`
  from ((`sjliyi`.`actorpowersheet` `a`
    join `sjliyi`.`actor` `b`) join `sjliyi`.`systemmenu` `c`)
  where ((`a`.`actorID` = `b`.`id`) and (`a`.`systemMenuID` = `c`.`id`))
  order by `a`.`actorID`;

