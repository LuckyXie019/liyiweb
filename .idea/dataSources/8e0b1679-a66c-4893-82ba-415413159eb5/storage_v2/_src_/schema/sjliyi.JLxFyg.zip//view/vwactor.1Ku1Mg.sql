create view vwactor as
  select
    `a`.`id`          AS `id`,
    `a`.`name`        AS `name`,
    `a`.`createDate`  AS `createDate`,
    `a`.`description` AS `description`,
    `a`.`type`        AS `type`,
    `a`.`status`      AS `status`,
    `a`.`parent`      AS `parent`,
    `b`.`name`        AS `typeName`,
    `b`.`type`        AS `actorTypeName`,
    `b`.`org`         AS `org`,
    `c`.`name`        AS `orgName`
  from ((`sjliyi`.`actor` `a`
    join `sjliyi`.`actortype` `b`) join `sjliyi`.`organization` `c`)
  where ((`a`.`type` = `b`.`id`) and (`b`.`org` = `c`.`id`));

