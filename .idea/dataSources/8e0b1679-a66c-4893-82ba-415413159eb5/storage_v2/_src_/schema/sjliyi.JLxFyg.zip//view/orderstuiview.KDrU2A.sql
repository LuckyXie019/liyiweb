create view orderstuiview as
  select
    `sjliyi`.`i_orders`.`id`              AS `id`,
    `sjliyi`.`i_orders`.`orders_id`       AS `orders_id`,
    `sjliyi`.`i_orders`.`c_id`            AS `c_id`,
    `sjliyi`.`i_orders`.`u_id`            AS `u_id`,
    `sjliyi`.`i_orders`.`a_receiver`      AS `a_receiver`,
    `sjliyi`.`i_orders`.`a_address`       AS `a_address`,
    `sjliyi`.`i_orders`.`a_phone`         AS `a_phone`,
    `sjliyi`.`i_orders`.`ordertime`       AS `ordertime`,
    `sjliyi`.`i_orders`.`goodsnumber`     AS `goodsnumber`,
    `sjliyi`.`i_orders`.`st_id`           AS `st_id`,
    `sjliyi`.`i_orders`.`shiptime`        AS `shiptime`,
    `sjliyi`.`i_orders`.`price`           AS `price`,
    `sjliyi`.`i_orders`.`reality`         AS `reality`,
    `sjliyi`.`i_orders`.`logisname`       AS `logisname`,
    `sjliyi`.`i_orders`.`logisticsnumber` AS `logisticsnumber`,
    `sjliyi`.`i_orders`.`status`          AS `status`,
    `sjliyi`.`i_orders`.`note`            AS `note`,
    `sjliyi`.`i_orders`.`sendername`      AS `sendername`,
    `sjliyi`.`i_orders`.`senderaddress`   AS `senderaddress`,
    `sjliyi`.`i_orders`.`evalustatus`     AS `evalustatus`,
    `sjliyi`.`i_orders`.`senderphone`     AS `senderphone`,
    `sjliyi`.`i_style`.`styleImage`       AS `styleImage`,
    `sjliyi`.`i_style`.`stylename`        AS `stylename`,
    `sjliyi`.`i_commodity`.`commname`     AS `commname`,
    `sjliyi`.`i_commodity`.`image1`       AS `image1`,
    `sjliyi`.`i_commodity`.`price`        AS `commprice`,
    `sjliyi`.`i_refund`.`refundstatus`    AS `refundstatus`,
    `sjliyi`.`i_refund`.`explains`        AS `explains`,
    `sjliyi`.`i_refund`.`reason`          AS `reason`,
    `sjliyi`.`i_refund`.`refundtime`      AS `refundtime`,
    `sjliyi`.`i_refund`.`id`              AS `refund_id`,
    `sjliyi`.`i_refund`.`refundresult`    AS `refundresult`,
    `sjliyi`.`i_refund`.`succeedtime`     AS `succeedtime`
  from (((`sjliyi`.`i_orders`
    join `sjliyi`.`i_commodity` on ((`sjliyi`.`i_orders`.`c_id` = `sjliyi`.`i_commodity`.`id`))) join `sjliyi`.`i_style`
      on ((`sjliyi`.`i_orders`.`st_id` = `sjliyi`.`i_style`.`id`))) join `sjliyi`.`i_refund`
      on ((`sjliyi`.`i_orders`.`id` = `sjliyi`.`i_refund`.`o_id`)));

