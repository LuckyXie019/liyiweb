create view vwactortype as
  select
    `a`.`id`         AS `id`,
    `a`.`name`       AS `name`,
    `a`.`createDate` AS `createDate`,
    `a`.`status`     AS `status`,
    `a`.`org`        AS `org`,
    `b`.`name`       AS `orgName`,
    `a`.`type`       AS `type`
  from (`sjliyi`.`actortype` `a`
    join `sjliyi`.`organization` `b`)
  where (`a`.`org` = `b`.`id`);

