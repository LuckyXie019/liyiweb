create view vwuseronlinerecord as
  select
    `a`.`id`         AS `id`,
    `a`.`name`       AS `name`,
    `a`.`ipAddress`  AS `ipAddress`,
    `a`.`loginUser`  AS `loginUser`,
    `a`.`loginDate`  AS `loginDate`,
    `a`.`logoutDate` AS `logoutDate`,
    `a`.`sessionID`  AS `sessionID`,
    `a`.`type`       AS `type`,
    `a`.`createDate` AS `createDate`,
    `a`.`status`     AS `status`,
    `b`.`nickName`   AS `userNickName`,
    `b`.`name`       AS `userName`,
    `b`.`status`     AS `userStatus`
  from (`sjliyi`.`users` `b`
    join `sjliyi`.`useronlinerecord` `a`)
  where (`a`.`loginUser` = `b`.`id`);

