create view commstyleview3 as
  select
    `sjliyi`.`i_store`.`id`              AS `storeid`,
    `sjliyi`.`i_commodity`.`id`          AS `id`,
    `sjliyi`.`i_commodity`.`commname`    AS `commname`,
    `sjliyi`.`i_commodity`.`sub_id`      AS `sub_id`,
    `sjliyi`.`i_commodity`.`title`       AS `title`,
    `sjliyi`.`i_commodity`.`image1`      AS `image1`,
    `sjliyi`.`i_commodity`.`image2`      AS `image2`,
    `sjliyi`.`i_commodity`.`image3`      AS `image3`,
    `sjliyi`.`i_commodity`.`image4`      AS `image4`,
    `sjliyi`.`i_commodity`.`description` AS `description`,
    `sjliyi`.`i_commodity`.`price`       AS `price`,
    `sjliyi`.`i_commodity`.`stock`       AS `stock`,
    `sjliyi`.`i_commodity`.`time`        AS `time`,
    `sjliyi`.`i_commodity`.`s_id`        AS `s_id`,
    `sjliyi`.`i_commodity`.`integral`    AS `integral`,
    `sjliyi`.`i_commodity`.`status`      AS `status`,
    `sjliyi`.`i_commodity`.`sales`       AS `sales`,
    `sjliyi`.`i_commodity`.`sstatus`     AS `sstatus`,
    `sjliyi`.`i_style`.`styleImage`      AS `styleImage`,
    `sjliyi`.`i_style`.`stylename`       AS `stylename`,
    `sjliyi`.`i_style`.`id`              AS `styleid`,
    `sjliyi`.`i_store`.`storename`       AS `storename`,
    `sjliyi`.`i_store`.`credit`          AS `credit`,
    `sjliyi`.`i_store`.`storeimage`      AS `storeimage`
  from ((`sjliyi`.`i_commodity`
    join `sjliyi`.`i_store` on ((`sjliyi`.`i_commodity`.`s_id` = `sjliyi`.`i_store`.`id`))) join `sjliyi`.`i_style`
      on ((`sjliyi`.`i_style`.`com_id` = `sjliyi`.`i_commodity`.`id`)));

