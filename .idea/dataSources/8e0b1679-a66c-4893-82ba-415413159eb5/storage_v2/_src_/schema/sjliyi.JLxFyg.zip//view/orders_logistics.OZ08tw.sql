create view orders_logistics as
  select
    `o`.`id`                     AS `id`,
    `o`.`a_receiver`             AS `a_receiver`,
    `o`.`a_address`              AS `a_address`,
    `o`.`a_phone`                AS `a_phone`,
    `o`.`ordertime`              AS `ordertime`,
    `c`.`commname`               AS `commname`,
    `c`.`price`                  AS `price`,
    `o`.`reality`                AS `reality`,
    `s`.`stylename`              AS `stylename`,
    `o`.`goodsnumber`            AS `goodsnumber`,
    `o`.`shiptime`               AS `shiptime`,
    `o`.`logisname`              AS `logisname`,
    `o`.`logisticsnumber`        AS `logisticsnumber`,
    `o`.`note`                   AS `note`,
    `o`.`status`                 AS `status`,
    `o`.`signtime`               AS `signtime`,
    `o`.`sendername`             AS `sendername`,
    `o`.`senderaddress`          AS `senderaddress`,
    `o`.`senderphone`            AS `senderphone`,
    `o`.`evalustatus`            AS `evalustatus`,
    `c`.`s_id`                   AS `s_id`,
    `sjliyi`.`i_user`.`id`       AS `user_id`,
    `sjliyi`.`i_user`.`nickname` AS `nickname`
  from ((((`sjliyi`.`i_orders` `o`
    join `sjliyi`.`i_commodity` `c` on ((`o`.`c_id` = `c`.`id`))) join `sjliyi`.`i_store`
      on ((`c`.`s_id` = `sjliyi`.`i_store`.`id`))) join `sjliyi`.`i_user`
      on ((`sjliyi`.`i_user`.`s_id` = `sjliyi`.`i_store`.`id`))) join `sjliyi`.`i_style` `s`
      on ((`o`.`st_id` = `s`.`id`)));

